DROP TABLE register_and_login IF EXISTS;
DROP TABLE goods IF EXISTS;

CREATE TABLE register_and_login (
  userID varchar(40) NOT NULL,
  password varchar(40) DEFAULT NULL,
  nick_name varchar(50) DEFAULT NULL,
  PRIMARY KEY (userID)
);

CREATE TABLE goods (
  goods_id int(11) NOT NULL AUTO_INCREMENT,
  imgURL varchar(5000) DEFAULT NULL,
  name varchar(100) DEFAULT NULL,
  description varchar(300) NOT NULL,
  classifi varchar(50) DEFAULT NULL,
  contact_me varchar(50) DEFAULT NULL,
  userID varchar(40) DEFAULT NULL,
  latitude double DEFAULT NULL,
  longitude double DEFAULT NULL,
  PRIMARY KEY (goods_id),
  foreign key(userID) references register_and_login(userID)
) AUTO_INCREMENT=0 ;

